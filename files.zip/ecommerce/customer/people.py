def print_name(name: str):
    print(name)
