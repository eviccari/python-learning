from ecommerce.customer.people import print_name  # absolute reference
from ..customer import people


def calc_tax():
    pass


def calc_shipping():
    pass
